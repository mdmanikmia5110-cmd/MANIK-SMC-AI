# MANIK SMC AI — Android starter project

This is an Android Studio project for Android 10+ (minSdk 29), with a premium black/silver UI and user-approved MediaProjection screen capture.

## Important capability boundary
This is a **starter MVP**, not a finished predictive trading engine. It can request permission and start a local screen-capture session. It does not yet identify Quotex candles, calculate OHLC, detect SMC structures, or generate validated BUY/SELL signals. The captured frames are intentionally not uploaded or stored. No trading is automated.

Quotex OTC data may not have a public, licensed real-time API. Screen pixels alone are not a dependable price feed: chart zoom, scaling, overlays, colors, and UI changes can invalidate candle detection. Never treat a visual heuristic as a reliable signal.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated debug APK on Android 10+.
6. Open MANIK SMC AI, tap START SCREEN SCAN, and approve Android's screen-capture prompt.

## Next engineering stages
- Add a user-selected chart crop and calibration (price scale / candle width).
- Implement pixel-based candle segmentation and confidence checks.
- Validate candle OHLC reconstruction against manually labelled screenshots.
- Add deterministic BOS/CHoCH, equal-high/low liquidity, FVG and order-block logic.
- Show WAIT when chart quality or confidence is insufficient.
- Test only on demo data before any real-money use.

## Privacy
The app does not request Quotex login credentials, accessibility permissions, contacts, microphone, or internet permission. Android shows a persistent notification while screen capture is active. Stop capture by tapping STOP SCAN or force-stopping the app.
