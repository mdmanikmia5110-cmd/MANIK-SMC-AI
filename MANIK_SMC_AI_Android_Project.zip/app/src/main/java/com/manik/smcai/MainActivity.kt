package com.manik.smcai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9,9,9)
        window.navigationBarColor = Color.rgb(9,9,9)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(9,9,9))
        }
        val title = TextView(this).apply {
            text = "MANIK  SMC AI"
            textSize = 27f; setTextColor(Color.rgb(205,205,205))
            gravity = Gravity.CENTER; letterSpacing = .08f
        }
        val sub = TextView(this).apply {
            text = "QUOTEX OTC  •  M1 VISUAL SCANNER"
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "STATUS: READY"
            textSize = 15f; setTextColor(Color.rgb(190,190,190))
            setPadding(0, 30, 0, 16)
        }
        result = TextView(this).apply {
            text = "WAIT\n\nচার্ট ক্যাপচার শুরু করুন।"
            textSize = 23f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(10, 38, 10, 38)
            setBackgroundColor(Color.rgb(27,27,27))
        }
        val start = Button(this).apply {
            text = "START SCREEN SCAN"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "STOP SCAN"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); status.text = "STATUS: STOPPED" }
        }
        val note = TextView(this).apply {
            text = "\nনোট: এটি একটি পরীক্ষামূলক visual scanner। এটি ক্যান্ডেলের নির্ভুল OHLC, OTC feed, বা ভবিষ্যৎ দাম জানে না। BUY/SELL সংকেত নিশ্চিত নয়। প্রথমে Demo account-এ পরীক্ষা করুন।"
            textSize = 13f; setTextColor(Color.rgb(175,175,175))
        }
        layout.addView(title); layout.addView(sub); layout.addView(status)
        layout.addView(result, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    private fun requestScreenCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode); putExtra("data", data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
            status.text = "STATUS: SCREEN CAPTURE ACTIVE"
            result.text = "SCANNING\n\nস্ক্রিন শেয়ার চালু হয়েছে। নিরাপত্তার জন্য Quotex password বা account access নেওয়া হয় না।"
        } else {
            status.text = "STATUS: PERMISSION NOT GRANTED"
        }
    }
}
